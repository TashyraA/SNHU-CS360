package com.example.eventtracker.data

import androidx.room.*

@Dao
interface EventDao {

    @Query("SELECT * FROM events ORDER BY id DESC")
    suspend fun getAll(): List<Event>

    @Query("SELECT * FROM events WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int): Event?

    @Insert
    suspend fun insert(event: Event)

    @Update
    suspend fun update(event: Event)

    @Query("DELETE FROM events WHERE id = :id")
    suspend fun deleteById(id: Int)
}

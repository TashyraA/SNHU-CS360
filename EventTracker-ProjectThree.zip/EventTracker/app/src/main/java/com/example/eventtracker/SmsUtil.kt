package com.example.eventtracker

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

object SmsUtil {

    private const val PREFS = "sms_prefs"
    private const val KEY_ENABLED = "sms_enabled"

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }

    fun isEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, false)
    }

    fun hasSmsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED
    }

    fun trySendSmsIfEnabled(context: Context, message: String) {
        if (!isEnabled(context)) return
        if (!hasSmsPermission(context)) return

        val phoneNumber = "5551234567" // change for real device testing
        SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null)
    }
}

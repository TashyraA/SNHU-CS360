package com.example.eventtracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class AddEditEventActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit_event)
    }
}

package com.example.eventtracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.eventtracker.data.AppDatabase
import com.example.eventtracker.data.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnCreate = findViewById<Button>(R.id.btnCreateAccount)

        val db = AppDatabase.getInstance(this)
        val userDao = db.userDao()

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter username and password.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                val user = withContext(Dispatchers.IO) { userDao.getUser(username) }

                if (user == null || user.password != password) {
                    Toast.makeText(this@LoginActivity, "Invalid login.", Toast.LENGTH_SHORT).show()
                } else {
                    startActivity(Intent(this@LoginActivity, EventListActivity::class.java))
                    finish()
                }
            }
        }

        btnCreate.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString()

            lifecycleScope.launch {
                val existing = withContext(Dispatchers.IO) { userDao.getUser(username) }
                if (existing != null) {
                    Toast.makeText(this@LoginActivity, "Username already exists.", Toast.LENGTH_SHORT).show()
                } else {
                    withContext(Dispatchers.IO) { userDao.insertUser(User(username, password)) }
                    Toast.makeText(this@LoginActivity, "Account created.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
